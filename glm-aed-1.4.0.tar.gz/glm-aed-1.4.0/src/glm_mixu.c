/******************************************************************************
 *                                                                            *
 * glm_mixu.c                                                                 *
 *                                                                            *
 * Developed by :                                                             *
 *     AquaticEcoDynamics (AED) Group                                         *
 *     School of Earth & Environment                                          *
 *     The University of Western Australia                                    *
 *                                                                            *
 *     http://aed.see.uwa.edu.au/                                             *
 *                                                                            *
 * Copyright 2013, 2014 -  The University of Western Australia                *
 *                                                                            *
 *  This file is part of GLM (General Lake Model)                             *
 *                                                                            *
 *  GLM is free software: you can redistribute it and/or modify               *
 *  it under the terms of the GNU General Public License as published by      *
 *  the Free Software Foundation, either version 3 of the License, or         *
 *  (at your option) any later version.                                       *
 *                                                                            *
 *  GLM is distributed in the hope that it will be useful,                    *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 *  GNU General Public License for more details.                              *
 *                                                                            *
 *  You should have received a copy of the GNU General Public License         *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.     *
 #                                                                            *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "glm.h"

#include "glm_types.h"
#include "glm_globals.h"

#include "aed_time.h"
#include "glm_util.h"
#include "glm_mixu.h"


/******************************************************************************/
void add_this_layer(REALTYPE *VMbig, REALTYPE *VMsml, REALTYPE *Tbig, REALTYPE *Tsml,
                    REALTYPE *Sbig, REALTYPE *Ssml, REALTYPE *VMLOC, REALTYPE *TMLOC,
                    REALTYPE *SMLOC, REALTYPE *DFLOC, int idx)
{
    REALTYPE WTbig;
    REALTYPE WTsml;

    WTbig = thsnd * Lake[idx].LayerVol;
    WTsml = Lake[idx].Density * Lake[idx].LayerVol;

    *VMbig += WTbig;
    *VMsml += WTsml;
    *Tbig  += (Lake[idx].Temp * WTbig);
    *Tsml  += (Lake[idx].Temp * WTsml);
    *Sbig  += (Lake[idx].Salinity * WTbig);
    *Ssml  += (Lake[idx].Salinity * WTsml);

    *VMLOC = *VMbig + *VMsml;
    *TMLOC = (*Tsml + *Tbig) / (*VMLOC);
    *SMLOC = (*Ssml + *Sbig) / (*VMLOC);

    *DFLOC = calculate_density(*TMLOC,*SMLOC);
}
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


/******************************************************************************
 * This routine assigns the mean mixed layer properties to all of the         *
 * layers in the epilimnion and increments the layer pointers j1,k1           *
 *----------------------------------------------------------------------------*/
void average_layer(int *j1, int *k1,
                            REALTYPE MeanTemp, REALTYPE MeanSalt, REALTYPE Dens)
{
    int i, jl = *j1;

    for (i = jl; i < NumLayers; i++) {
        Lake[i].Temp = MeanTemp;
        Lake[i].Salinity = MeanSalt;
        Lake[i].Density = Dens;
    }

    (*j1) -= 1;
    (*k1) -= 1;
}
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


/******************************************************************************/
static void one_layer(int i, REALTYPE *xx, REALTYPE *dxx)
{
    REALTYPE x, y;

    int ij;

    x = Lake[i].Height * ten;
    y = AMOD(x,one);
    ij = (x - y);
    if (ij > Nmorph) {
        y += (ij - Nmorph);
        ij = Nmorph;
    }
    ij--; /* offset for 0 based index */
    Lake[i].Vol1 = xx[ij] + y * dxx[ij];
    Lake[i].LayerArea = MphLevelArea[ij] + y * dMphLevelArea[ij];
}
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


/******************************************************************************
 * From the given physical data evaluates arrays of depths and areas          *
 * corresponding to an array of volumes (icode=2) or arrays of volume         *
 * and areas from depths (icode=1) starting at layer LNU                      *
 ******************************************************************************/
void resize_internals(int icode, int lnu)
{
   REALTYPE VolSum, x, y;

   int i, j, ij, k, l, ln;

//-------------------------------------------------------------------------------

    ln = lnu;
    if (icode == 1) {
        /**********************************************************************
         * Find volumes and areas given depths; ij points to storage table    *
         * entry closest to but less than the given depth, Y is the relative  *
         * location of DEPTH between storage table entries ij and ij+1.       *
         * Begin by calculating the total volume in the layer structure.      *
         **********************************************************************/
        VolSum = 0.0;
        for (k = 0; k < NumInf; k++)
            VolSum += Inflows[k].TotIn;

        while(1) {
            one_layer(surfLayer, MphLevelVol, dMphLevelVol);

            Lake[surfLayer].Vol1 -= VolSum;

            /* compute to one below current surface layer */
            for (i = ln; i < surfLayer; i++)
                one_layer(i, MphLevelVoldash, dMphLevelVolda);

            if (surfLayer <= botmLayer ||
                             Lake[surfLayer].Vol1 > Lake[surfLayer-1].Vol1)
                break;

            Lake[surfLayer-1].Vol1 = Lake[surfLayer].Vol1 + VolSum;
            Lake[surfLayer-1].LayerArea = Lake[surfLayer].LayerArea;
            Lake[surfLayer-1].Height = Lake[surfLayer].Height;
            Lake[surfLayer-1].Temp =
                    combine(Lake[surfLayer-1].Temp, Lake[surfLayer-1].LayerVol, Lake[surfLayer-1].Density,
                            Lake[surfLayer].Temp,   Lake[surfLayer].LayerVol,   Lake[surfLayer].Density);
            Lake[surfLayer-1].Salinity =
                    combine(Lake[surfLayer-1].Salinity, Lake[surfLayer-1].LayerVol, Lake[surfLayer-1].Density,
                            Lake[surfLayer].Salinity,   Lake[surfLayer].LayerVol,   Lake[surfLayer].Density);
            Lake[surfLayer-1].Density = calculate_density(Lake[surfLayer-1].Temp, Lake[surfLayer-1].Salinity);

            NumLayers--;
            if (surfLayer < ln) {
                if (--ln < botmLayer) {
                    fprintf(stderr,"surface layer less than bottom layer.\n");
                    exit(1);
                }
            }
        }
    } else {
        /**********************************************************************
         * calculate depths given volumes; J points to storage table volume   *
         * closest to but not greater than the given layer volume             *
         **********************************************************************/
        VolSum = Lake[surfLayer].Vol1;
        for (i = 0; i < NumInf; i++)
            VolSum += Inflows[i].TotIn;

        j = 0;
        while (j < Nmorph) {
            if (VolSum <= MphLevelVol[j]) {
                j--;
                break;
            }
            j++;
        }
        if (j >= Nmorph) j = Nmorph - 1;
        Lake[surfLayer].Height = ((j+1) + ((VolSum - MphLevelVol[j]) / dMphLevelVol[j])) / 10.;

        if (lnu <= botmLayer) {
            l = 0;
            j = 0;

            /* find lowest layer (L) whose volume exceeds the first table entry */
            while (Lake[l].Vol1 <= MphLevelVoldash[0]) {
                Lake[l].Height = (Lake[l].Vol1 / MphLevelVoldash[0]) / 10.;
                l++;
            }
        } else {
            x = Lake[lnu-1].Height * 10.;
            y = AMOD(x,one);
            j = (x - y) - 1;
            l = lnu;
        }

        /* comupute to one below current surface */
        for (k = l; k < surfLayer; k++) {
            while (j < Nmorph) {
                if (Lake[k].Vol1 <= MphLevelVoldash[j]) {
                    j--;
                    break;
                }
                j++;
            }
            if (j >= Nmorph) j = Nmorph - 1;

            Lake[k].Height = ((j+1) + (Lake[k].Vol1 - MphLevelVoldash[j]) / dMphLevelVolda[j]) / 10.;
        }

        //# determine areas
        for (i = lnu; i <= surfLayer; i++) {
            x = Lake[i].Height * 10.;
            y = AMOD(x,one);
            ij = (x - y) - 1;
            if (ij >= Nmorph) ij = Nmorph - 1;

            if (ij != -1) Lake[i].LayerArea = MphLevelArea[ij] + y * dMphLevelArea[ij];
            if (ij == -1) Lake[i].LayerArea = MphLevelArea[0] * Lake[i].Height * 10.;
        }
    }

    //# calculate layer volumes and mean depths
    ln = lnu;
    if (lnu == botmLayer) {
        Lake[botmLayer].LayerVol  = Lake[botmLayer].Vol1;
        Lake[botmLayer].MeanHeight = Lake[botmLayer].Height / 2.;
        ln = lnu+1;
    }

    for (i=ln; i <= surfLayer; i++) {
        Lake[i].LayerVol  = Lake[i].Vol1 - Lake[i-1].Vol1;
        Lake[i].MeanHeight = (Lake[i].Height + Lake[i-1].Height) / 2.;
    }
}
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
